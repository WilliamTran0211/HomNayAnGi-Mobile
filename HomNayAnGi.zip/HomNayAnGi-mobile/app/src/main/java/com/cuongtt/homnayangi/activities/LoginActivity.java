package com.cuongtt.homnayangi.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;

import com.cuongtt.homnayangi.R;
import com.google.android.material.textfield.TextInputLayout;


public class LoginActivity extends AppCompatActivity {

    private static final String TAG = "LoginActivity";

    private TextInputLayout edtEmail, edtPassword;
    private Button btnDangNhap, btnDangKy;

    public final String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        addControl();
        addEvents();

    }

    private void addEvents() {

        btnDangNhap.setEnabled(false);

        edtEmail.getEditText().addTextChangedListener(emailValidate);

        btnDangNhap.setOnClickListener(loginButtonClick);

        btnDangKy.setOnClickListener(registerButtonClick);

    }

    private void addControl() {
        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);
        btnDangKy = findViewById(R.id.btnDangKy);
        btnDangNhap = findViewById(R.id.btnDangNhap);
    }

    public View.OnClickListener loginButtonClick =  new View.OnClickListener() {
        @Override
        public void onClick(final View view) {
            final String email = edtEmail.getEditText().getText().toString().trim();
            final String password = edtPassword.getEditText().getText().toString().trim();


        }
    };


    public View.OnClickListener registerButtonClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(getApplication(), SignUpActivity.class);
            getApplication().startActivity(intent);
        }
    };

    public TextWatcher emailValidate = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        @Override
        public void afterTextChanged(Editable editable) {

            btnDangNhap.setEnabled(true);

            String email = edtEmail.getEditText().getText().toString().trim();

            if (email.matches(emailPattern) && editable.length() > 0)
            {
                edtEmail.setError(null);
            }else {
                edtEmail.setError("Email invalid");
            }

        }
    };

}
